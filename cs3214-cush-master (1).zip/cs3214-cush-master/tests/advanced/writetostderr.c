#include <stdio.h>

int
main()
{
    printf("stdout\n");
    fprintf(stderr, "stderr\n");
}
